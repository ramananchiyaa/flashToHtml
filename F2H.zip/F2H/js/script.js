var flashMediaPlayer = function(){
    console.log("2. flashMediaPlayer function invoked...");

    var _this = this;
    console.log(_this);

    _this.init = function(){
        console.log("3. init function invoked...")

        _this.preloaderScreen = $(".preloaderScreen");
        _this.subTitleBtn = $("#subTitleBtn"); console.log("4. subtitle", _this.subTitleBtn);
        _this.previousBtn = $("#previousBtn"); console.log("5. previousBtn", _this.previousBtn);
        _this.nextBtn = $("#nextBtn"); console.log("6. nextBtn", _this.nextBtn);
        _this.video = $("video")[0]; console.log("7. video", _this.nextBtn);

        _this.currentVideoTime = _this.video.currentTime;
        console.log("Start time", _this.currentVideoTime);

        _this.preload();  
    }

    _this.preload = function(){
        console.log("preload function invoked");
        _this.video.addEventListener('loadedmetadata', function(){
            _this.videoDuration = _this.video.duration;
            console.log(_this.videoDuration);
            _this.preloaderScreen.fadeOut("slow");
        })
        _this.muteUnmute();
        _this.playPause();
        _this.prevNextButton();
        _this.slider();
    }

    _this.muteUnmute = function(){
        console.log("muteUnmute function invoked");

        $("#audioMuteBtn").addClass('muteBtnon');

        $("#audioMuteBtn").click(function(){
            console.log('audioOnOff click');

            if($(this).hasClass('muteBtnon')){
                $(this).addClass('muteBtnoff');
                $(this).removeClass('muteBtnon');
                $("video").prop('muted', true);
            }
            else{
                $(this).addClass('muteBtnon');
                $(this).removeClass('muteBtnoff');
                $("video").prop('muted', false);
            }
        });
    }    

    _this.playPause = function(){
        console.log("playPause function invoked");

        $("#playPauseBtn").addClass('playBtn');

        $("#playPauseBtn").click(function(){
            console.log('playPause click');

            if($(this).hasClass('playBtn')){
                $(this).addClass('pauseBtn');
                $(this).removeClass('playBtn');
                _this.video.play();
            }
             else{
                $(this).addClass('playBtn');
                $(this).removeClass('pauseBtn')
                _this.video.pause();
             }
         });  
    }

    _this.prevNextButton = function(){
        console.log('prevNext function invoked');

        setInterval(function(){
            console.log("Current time", _this.video.currentTime);
        },500);

        _this.previousBtn.click(function(){
            var temp = _this.video.currentTime - 3;
            console.log('prev', temp);
            _this.video.currentTime  = temp;
        });

        _this.nextBtn.click(function(){
            var temp = _this.video.currentTime + 3;
            console.log('next', temp);
            _this.video.currentTime  = temp;
        })
    }

    _this.slider = function(){
        console.log('slider function invoked');
        $( "#slider" ).slider({
            start: function(event, ui){
                console.log(event, ui.value);
            },
            slide: function(event, ui){
                console.log(event, ui.value);
                _this.currentSlideTime = ui.value * _this.videoDuration/100;
                console.log(_this.currentSlideTime);
                _this.video.currentTime = _this.currentSlideTime;
                console.log(_this.video.currentTime);
            }
        });    
    }
    
    
        
}